package com.my.newproject39;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.AdapterView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.bumptech.glide.Glide;

public class MainActivity extends Activity {
	
	
	private HashMap<String, Object> blogfa = new HashMap<>();
	private String blogger_gen = "";
	private String blogger_id = "";
	private String rawdata = "";
	private double ki = 0;
	private String di = "";
	private String daydates = "";
	private HashMap<String, Object> converted = new HashMap<>();
	private String finedimage = "";
	private String post = "";
	private String ptitle = "";
	private String userimage = "";
	private String postcat = "";
	private String username = "";
	private String error = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> shut = new ArrayList<>();
	private ArrayList<String> allraw = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> readypost = new ArrayList<>();
	
	private ListView listview1;
	
	private RequestNetwork ra;
	private RequestNetwork.RequestListener _ra_request_listener;
	private AlertDialog.Builder d;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		listview1 = (ListView) findViewById(R.id.listview1);
		ra = new RequestNetwork(this);
		d = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				try {
					map = readypost.get((int)_position);
					i.setClass(getApplicationContext(), ViewActivity.class);
					i.putExtra("data", new Gson().toJson(map));
					startActivity(i);
					
					
					
				} catch(Exception e)
				
				{ 
					error = e.toString(); 
					
					SketchwareUtil.showMessage(getApplicationContext(), error);
					
					
				};
			}
		});
		
		_ra_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				_phrase_string(_response, _tag);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	private void initializeLogic() {
		blogfa = new HashMap<>();
		blogfa.put("maxResults", "50");
		blogger_id = "491289856704390916";
		blogger_gen = "https://www.googleapis.com/blogger/v3/blogs/".concat(blogger_id.concat("/posts"));
		blogfa.put("key", "AIzaSyBmhaj36x-PeHtbkbFDQ95R9mBkJJ1-LhQ");
		ra.setParams(blogfa, RequestNetworkController.REQUEST_PARAM);
		ra.startRequestNetwork(RequestNetworkController.GET, blogger_gen, "", _ra_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Customizar (final View _view, final String _cor, final double _arredondar, final double _elevar) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable ();
		gd.setColor (Color.parseColor (_cor));
		gd.setCornerRadius ((int)_arredondar);
		_view.setBackground (gd);
		_view.setElevation((int)_elevar);
	}
	
	
	private void _phrase_string (final String _response, final String _tag) {
		try {
			shut.clear();
			allraw.clear();
			readypost.clear();
			
			org.json.JSONObject mainn = new org.json.JSONObject(_response);
			
			rawdata = mainn.getString("items");
			org.json.JSONArray main=new org.json.JSONArray(rawdata);
			shut = new Gson().fromJson(rawdata, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			ki = 0;
			for(int _repeat282 = 0; _repeat282 < (int)(shut.size()); _repeat282++) {
				org.json.JSONObject list = main.getJSONObject((int)ki);
				
				//get post user name and img
				
				org.json.JSONObject temp = list.getJSONObject("author");
				
				username = temp.getString("displayName");
				
				org.json.JSONObject temp2 = temp.getJSONObject("image");
				
				userimage = temp2.getString("url");
				
				//end post user name
				
				//get post title content and img
				
				daydates = list.getString("published");
				post = list.getString("content");
				ptitle=list.getString("title");
				
				try{
					postcat = list.getString("labels");
				}catch (Exception e) { postcat = ("no labels");
				}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				di = daydates.replace("T", "");
				try{
					
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-ddHH:mm:ss"); 
					
					SimpleDateFormat df2 = new SimpleDateFormat("dd MMMM yyyy hh:mm a"); 
					
					Date date = format.parse(di);
					
					di = df2.format(date); 
					
				} catch (java.text.ParseException e) {
					
					 // TODO Auto-generated catch block
					
					 e.printStackTrace(); 
				};
				converted = new HashMap<>();
				finedimage = post.replace("\\", "").replace("\n", " ").replace("\\u", " ");
				List<String> allraw = new ArrayList<String>();
				
				
				java.util.regex.Pattern pattern = java.util.regex.Pattern.compile( "\\b(((ht|f)tp(s?)\\:\\/\\/|~\\/|\\/)|i1.wp.)" + "(\\w+:\\w+@)?(([-\\w]+\\.)+(com|org|net|gov" + "|mil|biz|info|mobi|name|aero|jobs|museum" + "|travel|[a-z]{2}))(:[\\d]{1,5})?" + "(((\\/([-\\w~!$+|.,=]|%[a-f\\d]{2})+)+|\\/)+|\\?|#)?" + "((\\?([-\\w~!$+|.,*:]|%[a-f\\d{2}])+=?" + "([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)" + "(&(?:[-\\w~!$+|.,*:]|%[a-f\\d{2}])+=?" + "([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)*)*" + "(#([-\\w~!$+|.,*:=]|%[a-f\\d]{2})*)?\\b"); 
				java.util.regex.Matcher matcher = pattern.matcher(finedimage);
				
				 while (matcher.find()) {
					
					allraw.add(matcher.group());
					
				};
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				if (allraw.size() > 1) {
					converted.put("img", allraw.get((int)(0)));
				}
				converted.put("title", ptitle);
				converted.put("content", post);
				converted.put("date", di);
				converted.put("authorimage", userimage.replace("//", ""));
				converted.put("labels", postcat);
				converted.put("author", username);
				readypost.add(converted);
				listview1.setAdapter(new Listview1Adapter(readypost));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				ki++;
			}
			
			
			
		} catch(Exception e)
		
		{ 
			error = e.toString(); 
			
			d.setMessage(error.concat("At position ".concat(String.valueOf((long)(ki)))));
			d.create().show();
			
			
		};
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cus, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView title = (TextView) _v.findViewById(R.id.title);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView date = (TextView) _v.findViewById(R.id.date);
			final TextView author = (TextView) _v.findViewById(R.id.author);
			
			try {
				title.setText(_data.get((int)_position).get("title").toString());
				date.setText(_data.get((int)_position).get("date").toString());
				author.setText(_data.get((int)_position).get("author").toString());
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img").toString())).into(imageview1);
				_Customizar(linear1, "#ffffffff", 35, 10);
				
				
				
			} catch(Exception e)
			
			{ 
				
				
				Log.e("Error: ", e.toString()); 
				
			} 
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
